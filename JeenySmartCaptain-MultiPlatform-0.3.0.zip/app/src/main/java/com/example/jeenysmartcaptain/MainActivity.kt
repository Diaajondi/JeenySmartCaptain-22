package com.example.jeenysmartcaptain

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("captain_multi", Context.MODE_PRIVATE) }
    private val purple = Color.rgb(91, 55, 180)
    private val dark = Color.rgb(28, 22, 52)
    private val bg = Color.rgb(246, 244, 251)
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun lp()=LinearLayout.LayoutParams(-1,-2)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }
    private fun render() {
        window.statusBarColor=dark; window.navigationBarColor=dark
        val root=LinearLayout(this).apply { orientation=1; setPadding(dp(18),dp(20),dp(18),dp(24)); setBackgroundColor(bg) }
        root.addView(TextView(this).apply { text="JEENY SMART CAPTAIN"; textSize=21f; setTextColor(dark); typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; setPadding(0,dp(8),0,dp(4)) },lp())
        root.addView(TextView(this).apply { text="مساعد قبول العروض الذكي"; textSize=14f; setTextColor(Color.DKGRAY); gravity=Gravity.CENTER; setPadding(0,0,0,dp(18)) },lp())
        val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=1 }
        content.addView(sectionTitle("حالة المنصات"))
        listOf("jeeny" to "Jeeny", "uber" to "Uber Driver", "taxif" to "TaxiF Driver").forEach { (key,label)->
            val card=card(); card.addView(TextView(this).apply { text=label; textSize=18f; typeface=Typeface.DEFAULT_BOLD; setTextColor(dark) },lp())
            val sw=Switch(this).apply { text="تشغيل القبول التلقائي"; isChecked=prefs.getBoolean("${key}_enabled",false); setTextColor(dark); textSize=15f }
            sw.setOnCheckedChangeListener { _,v -> prefs.edit().putBoolean("${key}_enabled",v).apply() }
            card.addView(sw,lp())
            when(key){
                "jeeny"->{ addField(card,key,"min_price","أقل سعر إجمالي (دينار)","3.00",true); addField(card,key,"max_eta","أقصى وقت وصول (دقيقة)","8",false) }
                "uber"->{ addField(card,key,"max_eta","أقصى وقت وصول (دقيقة)","8",false); addField(card,key,"max_distance","أقصى مسافة للعميل (كم)","5",true); addOptionalClose(card,key) }
                "taxif"->{ addField(card,key,"min_price","أقل قيمة للرحلة (دينار)","3.00",true); addField(card,key,"max_eta","أقصى وقت وصول (دقيقة)","8",false); addField(card,key,"max_distance","أقصى مسافة للعميل (كم)","5",true); addOptionalClose(card,key) }
            }
            content.addView(card,lp())
        }
        content.addView(sectionTitle("الصوت والإحصائيات"))
        val sound=Switch(this).apply { text="إعلان صوتي بعد تأكيد القبول"; setTextColor(dark); isChecked=prefs.getBoolean("sound_enabled",true); setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("sound_enabled",v).apply()} }
        content.addView(sound,lp())
        content.addView(TextView(this).apply { text="العدادات تسجل محاولات القبول المؤكدة فقط عند توفر إشارة نجاح واضحة من التطبيق المستهدف. لا تُعد ضغطة الزر وحدها رحلة مقبولة أو ربحاً."; textSize=12f; setTextColor(Color.DKGRAY); setPadding(0,dp(10),0,dp(14)) },lp())
        val access=Button(this).apply { text="فتح إعدادات إمكانية الوصول"; setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))} }
        content.addView(access,lp())
        content.addView(TextView(this).apply { text="تنبيه: يلزم اختبار قراءة كل منصة على هاتفك. تختلف أسماء الأزرار وطريقة عرض البيانات، وقد لا تكون بعض المعلومات متاحة لخدمة إمكانية الوصول."; textSize=12f; setTextColor(Color.GRAY); gravity=Gravity.CENTER; setPadding(0,dp(14),0,0) },lp())
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); setContentView(root)
    }
    private fun sectionTitle(s:String)=TextView(this).apply { text=s; textSize=17f; typeface=Typeface.DEFAULT_BOLD; setTextColor(purple); setPadding(0,dp(10),0,dp(8)) }
    private fun card()=LinearLayout(this).apply { orientation=1; setPadding(dp(16),dp(14),dp(16),dp(14)); setBackgroundColor(Color.WHITE); elevation=dp(2).toFloat(); setPadding(dp(16),dp(14),dp(16),dp(14)) }
    private fun addField(card:LinearLayout, platform:String, field:String, label:String, default:String, decimal:Boolean){
        card.addView(TextView(this).apply{text=label; textSize=14f; setTextColor(dark); setPadding(0,dp(10),0,dp(3))},lp())
        val edit=EditText(this).apply { hint=default; setSingleLine(true); inputType=if(decimal) 8194 else 2; setText(prefs.getString("${platform}_$field",default)); textSize=16f; setTextColor(dark) }
        edit.setOnFocusChangeListener { _,hasFocus -> if(!hasFocus) prefs.edit().putString("${platform}_$field",edit.text.toString()).apply() }
        card.addView(edit,lp())
    }
    private fun addOptionalClose(card:LinearLayout,key:String){ val sw=Switch(this).apply { text="إغلاق العرض غير المناسب بزر X"; setTextColor(dark); isChecked=prefs.getBoolean("${key}_close",false); setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("${key}_close",v).apply()} }; card.addView(sw,lp()) }
}
