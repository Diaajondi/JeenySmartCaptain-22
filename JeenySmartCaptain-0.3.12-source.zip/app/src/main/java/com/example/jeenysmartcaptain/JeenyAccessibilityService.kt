package com.example.jeenysmartcaptain

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.Rect
import android.media.RingtoneManager
import android.net.Uri
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Accessibility helper for driver offer cards.
 * Important: a Jeeny offer can be drawn in a non-focused application window
 * while another app (for example, Reels) remains the active window. Therefore
 * this service searches every interactive window and does not trust only
 * rootInActiveWindow or event.packageName.
 */
class JeenyAccessibilityService : AccessibilityService() {
    private var lastScanAt = 0L
    private var tts: TextToSpeech? = null

    private val acceptAttempts = mutableMapOf<String, Int>()
    private val lastAttemptAt = mutableMapOf<String, Long>()
    private val completedOffers = LinkedHashSet<String>()
    private val pendingConfirmation = mutableMapOf<String, Long>()
    private var pendingFare: Double? = null
    private var pendingOfferKey: String? = null
    private var pendingAcceptAt = 0L

    private data class PlatformRoot(
        val platform: String,
        val packageName: String,
        val root: AccessibilityNodeInfo,
        val windowType: Int
    )

    private data class AcceptTarget(
        val node: AccessibilityNodeInfo,
        val touchBounds: Rect
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        // Keep the manifest flags, and explicitly request all interactive windows
        // and nodes that apps may mark as not important for accessibility.
        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 80
            flags = flags or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        }
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ar")
        }
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("uber_enabled", false).apply()
        setStatus("خدمة الوصول تعمل؛ تنتظر عرض جيني")
        Log.i(TAG, "Accessibility service connected; interactive-window retrieval enabled")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType !in setOf(
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                AccessibilityEvent.TYPE_VIEW_SCROLLED,
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED,
                AccessibilityEvent.TYPE_WINDOWS_CHANGED,
                AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED
            )) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastScanAt < SCAN_THROTTLE_MS) return
        lastScanAt = now

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val roots = collectPlatformRoots(event)

        if (roots.isEmpty()) {
            val eventPackage = event.packageName?.toString().orEmpty()
            if (detectPlatform(eventPackage) != null) {
                setStatus("تم رصد حدث من التطبيق، لكن تعذر الوصول إلى نافذة العرض")
                Log.w(TAG, "Platform event received but no accessible platform window root was found")
            }
            return
        }

        for (entry in roots) {
            if (!prefs.getBoolean("${entry.platform}_enabled", false)) continue
            processPlatformWindow(entry, prefs, now)
        }
    }

    private fun collectPlatformRoots(event: AccessibilityEvent): List<PlatformRoot> {
        val found = LinkedHashMap<String, PlatformRoot>()

        fun addRoot(root: AccessibilityNodeInfo?, windowType: Int) {
            if (root == null) return
            val pkg = root.packageName?.toString()?.trim().orEmpty()
            if (pkg.isEmpty()) return
            val platform = detectPlatform(pkg) ?: return
            val key = "$platform|$pkg|${root.windowId}"
            if (!found.containsKey(key)) {
                found[key] = PlatformRoot(platform, pkg, root, windowType)
            }
        }

        // The offer overlay may not be the focused window. Inspect every window.
        try {
            for (window in windows) {
                try {
                    addRoot(window.root, window.type)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not read accessibility window root", e)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not enumerate interactive windows", e)
        }

        // Include active root even if the platform app did not emit the event.
        try {
            addRoot(rootInActiveWindow, -1)
        } catch (e: Exception) {
            Log.w(TAG, "Could not read active accessibility window", e)
        }

        // If the event came from a recognized driver package, include its event
        // source's root as an additional fallback even when windows[] is empty.
        try {
            val eventPackage = event.packageName?.toString().orEmpty()
            if (detectPlatform(eventPackage) != null) {
                val active = rootInActiveWindow
                if (active?.packageName?.toString() == eventPackage) addRoot(active, -3)
            }
        } catch (e: Exception) {
            Log.d(TAG, "Event package root fallback unavailable: ${e.javaClass.simpleName}")
        }

        // Some apps emit a useful source node before their window root is ready.
        try {
            var source = event.source
            var hops = 0
            while (source?.parent != null && hops < 20) {
                source = source.parent
                hops++
            }
            addRoot(source, -2)
        } catch (e: Exception) {
            Log.d(TAG, "Event source root unavailable: ${e.javaClass.simpleName}")
        }

        if (found.isNotEmpty()) {
            Log.d(TAG, "Platform windows found: " + found.values.joinToString { "${it.platform}:${it.packageName}:type=${it.windowType}" })
        }
        return found.values.toList()
    }

    private fun processPlatformWindow(
        entry: PlatformRoot,
        prefs: android.content.SharedPreferences,
        now: Long
    ) {
        val platform = entry.platform
        val root = entry.root
        val text = treeText(root)
        if (text.isBlank()) {
            setStatus("ظهرت نافذة ${entry.packageName} لكن شجرة النص فارغة")
            return
        }

        if (pendingFare != null && pendingAcceptAt > 0L) {
            if (now - pendingAcceptAt > 10000L) {
                pendingFare = null
                pendingAcceptAt = 0L
            } else if (isAcceptanceConfirmed(text)) {
                val fare = pendingFare ?: 0.0
                pendingOfferKey?.let { confirmedKey ->
                    completedOffers.add(confirmedKey)
                    acceptAttempts.remove(confirmedKey)
                    lastAttemptAt.remove(confirmedKey)
                    pendingConfirmation.remove(confirmedKey)
                }
                prefs.edit()
                    .putInt("accepted_count", prefs.getInt("accepted_count", 0) + 1)
                    .putString("income_total", (numberPref(prefs, "income_total", 0.0) + fare).toString())
                    .apply()
                pendingFare = null
                pendingOfferKey = null
                pendingAcceptAt = 0L
                trimState()
                playAcceptanceSound(prefs)
                setStatus("تم تأكيد قبول الرحلة؛ أضيفت إلى الإحصائيات")
                Log.i(TAG, "$platform acceptance confirmed; accepted count and estimated fare updated")
                return
            }
        }

        val offer = parseOffer(platform, text)
        if (offer == null) {
            // Record only a short diagnostic; do not save trip addresses or full screen text.
            Log.d(TAG, "$platform window found, but no fare/time pair could be parsed; chars=${text.length}")
            setStatus("تم العثور على نافذة Jeeny، لكن لم أتعرف على السعر ووقت الوصول")
            return
        }

        val key = offerKey(platform, offer, text)
        if (key in completedOffers) return

        val maxEta = intPref(prefs, "${platform}_max_eta", if (platform == "jeeny") 10 else 10)
        val acceptable = when (platform) {
            "jeeny" -> {
                val minPrice = numberPref(prefs, "jeeny_min_price", 1.0)
                offer.price != null && offer.eta != null && offer.price >= minPrice && offer.eta <= maxEta
            }
            "uber" -> {
                val minDistanceKm = numberPref(prefs, "uber_min_distance", 3.0)
                offer.distance != null && offer.eta != null && offer.distance >= minDistanceKm && offer.eta <= maxEta
            }
            else -> false
        }

        Log.i(TAG, "$platform offer parsed: fare=${offer.price}, eta=${offer.eta}, distance=${offer.distance}, acceptable=$acceptable, package=${entry.packageName}")
        if (!acceptable) {
            val rejectTarget = findReject(root) ?: findCloseFallback(root)
            val rejected = rejectTarget?.let { clickNodeOrTap(it) } == true
            if (rejected) {
                completedOffers.add(key)
                trimState()
                prefs.edit().putInt("rejected_count", prefs.getInt("rejected_count", 0) + 1).apply()
                setStatus("تم إرسال أمر رفض العرض غير المناسب")
            } else {
                setStatus("العرض غير مناسب، لكن زر الرفض/الإغلاق غير ظاهر")
                Log.w(TAG, "$platform unsuitable offer found but no accessible reject/close control")
            }
            Log.i(TAG, "$platform unsuitable offer reject dispatched=$rejected")
            return
        }

        val attempts = acceptAttempts[key] ?: 0
        if (attempts >= MAX_ACCEPT_ATTEMPTS) {
            setStatus("العرض مناسب، لكن لم يظهر تأكيد بعد $MAX_ACCEPT_ATTEMPTS محاولات")
            return
        }
        val previousAttempt = lastAttemptAt[key] ?: 0L
        if (now - previousAttempt < ACCEPT_RETRY_MS) return

        val target = findAccept(root, platform)
        if (target == null) {
            setStatus("قرأت عرضًا مناسبًا، لكن زر قبول العرض غير ظاهر في بيانات الوصول")
            Log.w(TAG, "$platform offer is eligible but no accept-label node was exposed by accessibility")
            return
        }

        val dispatched = when {
            attempts == 0 -> clickNodeOrTap(target)
            attempts == 1 -> dispatchSwipe(target.touchBounds, leftToRight = true)
            else -> dispatchSwipe(target.touchBounds, leftToRight = false)
        }

        acceptAttempts[key] = attempts + 1
        lastAttemptAt[key] = now
        pendingConfirmation[key] = now
        // Uber cards in this layout show distance/ETA, not a reliable fare.
        // Count a confirmed Uber acceptance, but do not add a fabricated fare to income.
        pendingFare = offer.price ?: 0.0
        pendingOfferKey = key
        pendingAcceptAt = now
        trimState()

        if (dispatched) {
            setStatus("تم إرسال محاولة ${attempts + 1} لقبول عرض مستوفٍ للشروط؛ ننتظر تأكيد Jeeny")
            Log.i(TAG, "$platform accept input dispatched; attempt=${attempts + 1}; awaiting visible confirmation")
        } else {
            setStatus("تعذر إرسال النقر أو السحب إلى زر القبول؛ قد لا تكون نافذة العرض قابلة للتحكم")
            Log.w(TAG, "$platform click/swipe dispatch failed for accept button")
        }
    }

    private fun offerKey(platform: String, offer: Offer, text: String): String {
        // Include route/category text as well as parsed values to separate similar offers.
        val stableText = text.lowercase()
            .replace(Regex("\\d+\\s*(?:دقيقة|دقائق|دقيقه|دقايق|min\\.?|mins?|minutes?)"), "ETA")
            .replace(Regex("\\s+"), " ")
        return "$platform|${offer.price}|${offer.eta}|${offer.distance}|${stableText.hashCode()}"
    }

    private fun trimState() {
        while (completedOffers.size > 40) completedOffers.remove(completedOffers.first())
        if (acceptAttempts.size > 40) {
            val keep = acceptAttempts.keys.toList().takeLast(20).toSet()
            acceptAttempts.keys.retainAll(keep)
            lastAttemptAt.keys.retainAll(keep)
            pendingConfirmation.keys.retainAll(keep)
        }
    }

    private fun setStatus(message: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("service_status", message)
            .putLong("service_status_at", System.currentTimeMillis())
            .apply()
    }

    private fun isAcceptanceConfirmed(raw: String): Boolean {
        val t = norm(raw).lowercase()
        val confirmations = listOf(
            "تم قبول الرحلة", "تم قبول الطلب", "تم قبول العرض", "تم تأكيد الرحلة", "تم استلام الرحلة",
            "رحلة مقبولة", "تمت الموافقة على الرحلة", "جاري التوجه إلى الراكب",
            "trip accepted", "ride accepted", "accepted successfully", "request accepted", "booking confirmed"
        )
        return confirmations.any { t.contains(it) }
    }

    private fun playAcceptanceSound(prefs: android.content.SharedPreferences) {
        try {
            val stored = prefs.getString("notification_sound_uri", "system_default") ?: "system_default"
            val uri = if (stored == "system_default") RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(stored)
            (RingtoneManager.getRingtone(this, uri))?.play()
        } catch (e: Exception) {
            Log.w(TAG, "Unable to play selected notification sound", e)
        }
    }

    private data class Offer(val price: Double?, val eta: Int?, val distance: Double?)

    private fun detectPlatform(pkg: String): String? {
        val s = pkg.lowercase()
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString().lowercase()
        } catch (_: Exception) { "" }
        val v = "$s $label"
        // Uber remains visible in the app as Coming Soon, but is not processed
        // by the accessibility service in this release.
        return if ("jeeny" in v) "jeeny" else null
    }

    private fun treeText(node: AccessibilityNodeInfo): String {
        val parts = mutableListOf<String>()
        val seen = HashSet<Int>()
        fun walk(current: AccessibilityNodeInfo) {
            if (!seen.add(current.hashCode())) return
            current.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(parts::add)
            current.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let(parts::add)
            for (i in 0 until current.childCount) {
                try { current.getChild(i)?.let(::walk) } catch (_: Exception) { }
            }
        }
        walk(node)
        return parts.distinct().joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun norm(value: String): String = value.map {
        when (it) {
            in '٠'..'٩' -> ('0'.code + it.code - '٠'.code).toChar()
            in '۰'..'۹' -> ('0'.code + it.code - '۰'.code).toChar()
            '٫' -> '.'
            '٬' -> ','
            else -> it
        }
    }.joinToString("").replace(',', '.')

    private fun parseOffer(platform: String, raw: String): Offer? {
        val t = norm(raw).lowercase()
        val eta = Regex("(?:على\\s+بعد\\s*)?(\\d{1,3})\\s*(?:د(?:قيقة|قائق|قيقه|قايق)?|min\\.?|mins?|minutes?)")
            .find(t)?.groupValues?.get(1)?.toIntOrNull()
        val distance = Regex("(\\d{1,3}(?:\\.\\d{1,2})?)\\s*(?:كم|كيلومتر|km|kilometers?)")
            .find(t)?.groupValues?.get(1)?.toDoubleOrNull()
        val currency = Regex("(?i)(?:jod|jd|د\\.?[اأإ]|دينار(?:\\s+أردني)?)\\s*[:：]?\\s*(\\d{1,5}(?:\\.\\d{1,2})?)|(\\d{1,5}(?:\\.\\d{1,2})?)\\s*(?:jod|jd|د\\.?[اأإ]|دينار(?:\\s+أردني)?)")
        // Jeeny's offer overlay may include the wallet balance (e.g. JOD 5.36)
        // as well as the actual fare (e.g. JOD 1.80). Keep the original order:
        // after trying an explicit total-fare label, the fare is the last
        // currency amount in the offer-card text, not the first wallet amount.
        val money = currency.findAll(t).mapNotNull {
            (it.groups[1]?.value ?: it.groups[2]?.value)?.toDoubleOrNull()
        }.toList()
        val totalWords = listOf("السعر الإجمالي", "السعر الاجمالي", "الإجمالي", "الاجمالي", "قيمة الرحلة", "قيمة الطلب", "total fare", "total")
        var price: Double? = null
        for (label in totalWords) {
            val index = t.indexOf(label)
            if (index >= 0) {
                val tail = t.substring(index).take(120)
                price = currency.find(tail)?.let { (it.groups[1]?.value ?: it.groups[2]?.value)?.toDoubleOrNull() }
                if (price != null) break
            }
        }
        if (price == null) price = money.lastOrNull()
        return if (eta == null && distance == null && price == null) null else Offer(price, eta, distance)
    }

    private fun numberPref(prefs: android.content.SharedPreferences, key: String, default: Double): Double =
        norm(prefs.getString(key, default.toString()) ?: default.toString()).toDoubleOrNull() ?: default

    private fun intPref(prefs: android.content.SharedPreferences, key: String, default: Int): Int =
        norm(prefs.getString(key, default.toString()) ?: default.toString()).toDoubleOrNull()?.toInt() ?: default

    private fun findAccept(root: AccessibilityNodeInfo, platform: String): AcceptTarget? {
        val phrases = if (platform == "jeeny") {
            listOf("قبول العرض", "قبول الطلب", "accept offer", "accept request", "accept")
        } else {
            listOf("أقبل", "اقبل", "قبول الرحلة", "قبول الطلب", "قبول العرض", "accept trip", "accept ride", "accept")
        }
        var best: AcceptTarget? = null
        var bestScore = -1

        fun visit(node: AccessibilityNodeInfo) {
            val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".trim().lowercase()
            val phrase = phrases.firstOrNull { label.contains(it) }
            if (phrase != null && node.isVisibleToUser) {
                val bounds = buttonTouchBounds(node)
                if (!bounds.isEmpty) {
                    val score = (if (phrase == "قبول العرض" || phrase == "accept offer") 100 else 50) +
                        (if (node.isClickable || hasClickableParent(node)) 20 else 0) +
                        (bounds.width() / 100)
                    if (score > bestScore) {
                        bestScore = score
                        best = AcceptTarget(node, bounds)
                    }
                }
            }
            for (i in 0 until node.childCount) {
                try { node.getChild(i)?.let(::visit) } catch (_: Exception) { }
            }
        }
        visit(root)
        if (best != null) return best
        if (platform == "uber") return findBottomAcceptFallback(root)
        return null
    }

    private fun findBottomAcceptFallback(root: AccessibilityNodeInfo): AcceptTarget? {
        val screen = Rect()
        root.getBoundsInScreen(screen)
        if (screen.isEmpty) return null
        // Uber's visible blue accept button is a wide control at the bottom of
        // the offer sheet; this fallback is used only after offer parsing and
        // eligibility checks have succeeded and no labelled node was exposed.
        val tapY = (screen.top + screen.height() * 0.92f).toInt()
        val tapX = screen.centerX()
        val half = (48 * resources.displayMetrics.density).toInt()
        return AcceptTarget(root, Rect(tapX - half, tapY - half, tapX + half, tapY + half))
    }

    private fun buttonTouchBounds(node: AccessibilityNodeInfo): Rect {
        val nodeRect = Rect()
        node.getBoundsInScreen(nodeRect)
        var current: AccessibilityNodeInfo? = node
        repeat(7) {
            if (current == null) return@repeat
            val rect = Rect()
            current?.getBoundsInScreen(rect)
            val minWidth = (resources.displayMetrics.widthPixels * 0.55f).toInt()
            val minHeight = (30 * resources.displayMetrics.density).toInt()
            val maxHeight = (140 * resources.displayMetrics.density).toInt()
            if (rect.width() >= minWidth && rect.height() in minHeight..maxHeight && rect.contains(nodeRect)) {
                return rect
            }
            current = current?.parent
        }
        return nodeRect
    }

    private fun findReject(root: AccessibilityNodeInfo): AcceptTarget? {
        var result: AcceptTarget? = null
        val labels = listOf("رفض العرض", "رفض الطلب", "رفض الرحلة", "تخطي", "رفض", "decline", "reject", "skip", "close", "إغلاق", "x", "×")
        fun visit(node: AccessibilityNodeInfo) {
            val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".trim().lowercase()
            if (labels.any { if (it == "x" || it == "×") label == it else label == it || label.contains(it) } &&
                (node.isClickable || hasClickableParent(node)) && node.isVisibleToUser) {
                val bounds = buttonTouchBounds(node)
                if (!bounds.isEmpty) { result = AcceptTarget(node, bounds); return }
            }
            for (i in 0 until node.childCount) {
                try { node.getChild(i)?.let(::visit) } catch (_: Exception) { }
            }
        }
        visit(root)
        return result
    }

    private fun findCloseFallback(root: AccessibilityNodeInfo): AcceptTarget? {
        val screen = Rect()
        root.getBoundsInScreen(screen)
        if (screen.isEmpty) return null
        var titleCenterY: Int? = null
        fun scan(node: AccessibilityNodeInfo) {
            val label = "${node.text ?: ""} ${node.contentDescription ?: ""}".lowercase()
            if (titleCenterY == null && (label.contains("economy") || label.contains("إيكونومي"))) {
                val b = Rect(); node.getBoundsInScreen(b)
                if (!b.isEmpty) titleCenterY = b.centerY()
            }
            for (i in 0 until node.childCount) try { node.getChild(i)?.let(::scan) } catch (_: Exception) { }
        }
        scan(root)
        val y = titleCenterY ?: (screen.top + screen.height() * 0.70f).toInt()
        val x = (screen.left + screen.width() * 0.14f).toInt()
        val half = (28 * resources.displayMetrics.density).toInt()
        Log.w(TAG, "No labelled close node; using offer-card close icon fallback")
        return AcceptTarget(root, Rect(x - half, y - half, x + half, y + half))
    }

    private fun hasClickableParent(node: AccessibilityNodeInfo): Boolean {
        var parent = node.parent
        repeat(6) {
            if (parent?.isClickable == true) return true
            parent = parent?.parent
        }
        return false
    }

    private fun clickNodeOrTap(target: AcceptTarget): Boolean {
        val node = target.node
        if (node.isClickable && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        try { if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true } catch (_: Exception) { }
        var parent = node.parent
        repeat(6) {
            if (parent?.isClickable == true && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            parent = parent?.parent
        }
        return dispatchTap(target.touchBounds)
    }

    private fun dispatchTap(bounds: Rect): Boolean {
        if (bounds.width() < 8 || bounds.height() < 8) return false
        val x = bounds.centerX().toFloat()
        val y = bounds.centerY().toFloat()
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90))
            .build()
        return try { dispatchGesture(gesture, null, null) } catch (e: Exception) {
            Log.w(TAG, "Tap gesture could not be dispatched", e); false
        }
    }

    private fun dispatchSwipe(bounds: Rect, leftToRight: Boolean): Boolean {
        if (bounds.width() < 60 || bounds.height() < 20) return false
        val y = bounds.centerY().toFloat()
        val inset = (bounds.width() * 0.10f).coerceAtLeast(12f)
        val startX = if (leftToRight) bounds.left + inset else bounds.right - inset
        val endX = if (leftToRight) bounds.right - inset else bounds.left + inset
        val path = Path().apply { moveTo(startX, y); lineTo(endX, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 520))
            .build()
        return try { dispatchGesture(gesture, null, null) } catch (e: Exception) {
            Log.w(TAG, "Swipe gesture could not be dispatched", e); false
        }
    }

    override fun onInterrupt() {}

    companion object {
        private const val TAG = "SmartCaptain"
        private const val PREFS = "captain_multi"
        private const val SCAN_THROTTLE_MS = 100L
        private const val ACCEPT_RETRY_MS = 650L
        private const val MAX_ACCEPT_ATTEMPTS = 3
    }
}
