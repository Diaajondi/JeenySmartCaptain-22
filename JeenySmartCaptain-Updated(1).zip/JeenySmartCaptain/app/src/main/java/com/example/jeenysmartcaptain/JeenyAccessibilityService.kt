package com.example.jeenysmartcaptain

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Context
import android.os.SystemClock
import android.util.Log

class JeenyAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private var lastOfferKey = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED &&
            event.eventType != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) return

        val prefs = getSharedPreferences("captain", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val root = rootInActiveWindow ?: return
        val minPrice = prefs.getString("min_price", "3.00")?.toDoubleOrNull() ?: return
        val maxMinutes = prefs.getInt("max_minutes", 8)

        val acceptNodes = mutableListOf<AccessibilityNodeInfo>()
        collectAcceptNodes(root, acceptNodes)
        for (accept in acceptNodes) {
            val card = findOfferContainer(accept) ?: continue
            val cardText = subtreeText(card)
            val price = extractPrice(cardText) ?: continue
            val eta = extractEta(cardText) ?: continue
            val offerKey = "${price}|${eta}|${cardText.take(500)}"
            if (offerKey == lastOfferKey) continue

            val now = SystemClock.elapsedRealtime()
            if (now - lastActionAt < 80) return

            if (price < minPrice || eta > maxMinutes) {
                // Dismiss only a clearly labelled close control inside this offer card.
                val close = findCloseControl(card)
                lastOfferKey = offerKey
                lastActionAt = now
                val dismissed = close?.let { clickNodeOrParent(it) } ?: false
                Log.i("JeenyCaptain", "Rejected offer price=$price eta=$eta; close clicked=$dismissed")
                return
            }

            lastOfferKey = offerKey
            lastActionAt = now
            val clicked = clickNodeOrParent(accept)
            Log.i("JeenyCaptain", "Accept click dispatched=$clicked price=$price eta=$eta")
            return
        }
    }

    private fun collectAcceptNodes(node: AccessibilityNodeInfo, result: MutableList<AccessibilityNodeInfo>) {
        val value = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if ("$value $desc".contains("قبول العرض") || "$value $desc".contains("قبول الطلب") ||
            "$value $desc".contains("accept")) result.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collectAcceptNodes(it, result) }
    }

    private fun findOfferContainer(accept: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var current: AccessibilityNodeInfo? = accept
        repeat(7) {
            val node = current ?: return null
            val text = subtreeText(node)
            if (extractPrice(text) != null && extractEta(text) != null) return node
            current = node.parent
        }
        return null
    }

    private fun subtreeText(node: AccessibilityNodeInfo): String {
        val parts = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo) {
            n.text?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(parts::add)
            n.contentDescription?.toString()?.trim()?.takeIf { it.isNotBlank() }?.let(parts::add)
            for (i in 0 until n.childCount) n.getChild(i)?.let(::walk)
        }
        walk(node)
        return parts.joinToString(" | ")
    }

    private fun findCloseControl(card: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        fun walk(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            val label = normalizeDigits(node.text?.toString().orEmpty()).trim().lowercase()
            val desc = node.contentDescription?.toString().orEmpty().trim().lowercase()
            val viewId = try { node.viewIdResourceName.orEmpty().lowercase() } catch (_: Exception) { "" }
            val explicitClose = label in setOf("x", "×", "✕", "إغلاق", "اغلاق", "close", "dismiss", "رفض", "تجاهل") ||
                desc in setOf("x", "×", "✕", "إغلاق", "اغلاق", "close", "dismiss", "رفض", "تجاهل") ||
                viewId.contains("close") || viewId.contains("dismiss")
            if (explicitClose && (node.isClickable || hasClickableParent(node))) return node
            for (i in 0 until node.childCount) {
                val found = node.getChild(i)?.let(::walk)
                if (found != null) return found
            }
            return null
        }
        return walk(card)
    }

    private fun hasClickableParent(node: AccessibilityNodeInfo): Boolean {
        var parent = node.parent
        repeat(3) {
            if (parent?.isClickable == true) return true
            parent = parent?.parent
        }
        return false
    }

    private fun normalizeDigits(s: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val persian = "۰۱۲۳۴۵۶۷۸۹"
        return s.map { c ->
            when {
                c in arabic -> ('0'.code + arabic.indexOf(c)).toChar()
                c in persian -> ('0'.code + persian.indexOf(c)).toChar()
                else -> c
            }
        }.joinToString("")
    }

    private fun extractPrice(text: String): Double? {
        val normalized = normalizeDigits(text)
            .replace('٫', '.')
            .replace(',', '.')
            .replace(Regex("\\s+"), " ")
        val totalLabels = listOf(
            "السعر الإجمالي", "السعر الاجمالي", "الإجمالي", "الاجمالي",
            "المجموع", "المبلغ الإجمالي", "المبلغ الاجمالي", "total", "grand total"
        )
        val amount = Regex("(?<![\\w])(?:JOD\\s*)?(\\d{1,5}(?:\\.\\d{1,3})?)(?:\\s*(?:JOD|JD|د\\.?أ|دينار(?: أردني)?))?(?![\\w])", RegexOption.IGNORE_CASE)

        // Prefer a number explicitly associated with a total label. Do not mistake
        // a per-kilometre, base-fare, or distance component for the total.
        for (label in totalLabels) {
            val index = normalized.indexOf(label, ignoreCase = true)
            if (index < 0) continue
            val after = normalized.substring(index + label.length).take(90)
            val before = normalized.substring(maxOf(0, index - 50), index)
            val matchAfter = amount.find(after)
            val matchBefore = amount.findAll(before).lastOrNull()
            val candidate = matchAfter?.groupValues?.get(1) ?: matchBefore?.groupValues?.get(1)
            candidate?.toDoubleOrNull()?.let { return it }
        }

        // If the card contains exactly one monetary amount, it is safe to use.
        // If it contains several amounts and no total label, fail closed instead
        // of accepting based on the first/lowest fare component.
        val currencyAmount = Regex(
            "(?i)(?:JOD|JD|د\\.?أ|دينار(?: أردني)?|\\$)\\s*(\\d{1,5}(?:\\.\\d{1,3})?)|" +
                "(\\d{1,5}(?:\\.\\d{1,3})?)\\s*(?:JOD|JD|د\\.?أ|دينار(?: أردني)?|\\$)"
        )
        val values = currencyAmount.findAll(normalized)
            .mapNotNull { (it.groups[1]?.value ?: it.groups[2]?.value)?.toDoubleOrNull() }
            .distinct()
            .toList()
        return values.singleOrNull()
    }

    private fun extractEta(text: String): Int? {
        val t = normalizeDigits(text)
        val regex = Regex("(?i)(\\d+)\\s*(?:دقيقة|دقائق|دقيقه|دقايق|min|mins|minutes)")
        return regex.find(t)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        repeat(4) {
            if (parent != null && parent.isClickable) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            parent = parent?.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
