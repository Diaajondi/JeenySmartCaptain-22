package com.example.jeenysmartcaptain

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("captain", Context.MODE_PRIVATE) }
    private lateinit var minPrice: EditText
    private lateinit var maxMinutes: EditText
    private lateinit var enabled: Switch

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 22, 48)
        window.navigationBarColor = Color.rgb(7, 22, 48)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(20), dp(22), dp(24))
            setBackgroundColor(Color.rgb(244, 247, 251))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.jeeny_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Jeeny Smart Captain"
        }
        page.addView(logo, LinearLayout.LayoutParams(dp(148), dp(148)).apply { bottomMargin = dp(8) })

        page.addView(TextView(this).apply {
            text = "Jeeny Smart Captain"
            textSize = 24f
            setTextColor(Color.rgb(7, 22, 48))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        page.addView(TextView(this).apply {
            text = "إعدادات قبول العروض تلقائياً"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(18))
        })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.WHITE)
        }
        panel.addView(fieldLabel("أقل سعر إجمالي بالدينار"))
        minPrice = EditText(this).apply {
            hint = "مثال: 3.00"
            inputType = 8194
            setSingleLine(true)
            setText(prefs.getString("min_price", "3.00"))
        }
        panel.addView(minPrice, matchWidth())

        panel.addView(fieldLabel("أقصى وقت وصول بالدقائق").apply { setPadding(0, dp(16), 0, 0) })
        maxMinutes = EditText(this).apply {
            hint = "مثال: 8"
            inputType = 2
            setSingleLine(true)
            setText(prefs.getInt("max_minutes", 8).toString())
        }
        panel.addView(maxMinutes, matchWidth())

        enabled = Switch(this).apply {
            text = "تفعيل القبول التلقائي"
            textSize = 16f
            isChecked = prefs.getBoolean("enabled", false)
            setPadding(0, dp(18), 0, dp(12))
        }
        panel.addView(enabled)

        val save = Button(this).apply {
            text = "حفظ الإعدادات"
            setOnClickListener {
                val p = minPrice.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val m = maxMinutes.text.toString().trim().toIntOrNull()
                if (p == null || p < 0 || m == null || m < 0) {
                    Toast.makeText(this@MainActivity, "أدخل سعراً ووقتاً صحيحين", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("min_price", p.toString())
                        .putInt("max_minutes", m).putBoolean("enabled", enabled.isChecked).apply()
                    Toast.makeText(this@MainActivity, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
                }
            }
        }
        panel.addView(save, matchWidth())

        val accessibility = Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        panel.addView(accessibility, matchWidth())
        page.addView(panel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        page.addView(TextView(this).apply {
            text = "إذا لم يطابق العرض شرط السعر أو وقت الوصول، يحاول التطبيق الضغط على زر X لإغلاق بطاقة العرض وإيقاف تنبيهها. يجب أن يكون زر الإغلاق واضحاً داخل البطاقة."
            textSize = 13f
            setTextColor(Color.rgb(65, 75, 90))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(16), dp(8), dp(8))
        })
        page.addView(TextView(this).apply {
            text = "ملاحظة: سرعة القراءة والضغط تعتمد على ما تعرضه جيني لخدمة إمكانية الوصول، ويجب اختبار التطبيق أولاً مع إيقاف القبول التلقائي."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        })

        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun fieldLabel(value: String) = TextView(this).apply {
        text = value
        textSize = 15f
        setTextColor(Color.rgb(35, 45, 60))
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun matchWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
