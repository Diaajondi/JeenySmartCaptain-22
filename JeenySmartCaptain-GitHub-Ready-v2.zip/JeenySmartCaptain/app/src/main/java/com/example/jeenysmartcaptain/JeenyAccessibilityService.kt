package com.example.jeenysmartcaptain

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Context
import android.os.SystemClock
import android.util.Log

class JeenyAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private var lastOfferKey = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences("captain", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return
        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        val acceptNodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, texts, acceptNodes)
        val all = texts.joinToString(" | ")
        val price = extractPrice(all) ?: return
        val eta = extractEta(all) ?: return
        val accept = acceptNodes.firstOrNull() ?: return
        val minPrice = prefs.getString("min_price", "3.00")?.toDoubleOrNull() ?: return
        val maxMinutes = prefs.getInt("max_minutes", 8)
        val offerKey = "$price|$eta|$all"
        if (offerKey == lastOfferKey) return
        if (price < minPrice || eta > maxMinutes) {
            lastOfferKey = offerKey
            Log.i("JeenyCaptain", "Ignored offer: price=$price eta=$eta")
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < 1800) return
        lastOfferKey = offerKey
        lastActionAt = now
        val clicked = clickNodeOrParent(accept)
        Log.i("JeenyCaptain", "Accept click dispatched=$clicked price=$price eta=$eta")
    }

    private fun collect(node: AccessibilityNodeInfo, texts: MutableList<String>,
                        buttons: MutableList<AccessibilityNodeInfo>) {
        val value = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        if (value.isNotBlank()) texts.add(value)
        if (desc.isNotBlank()) texts.add(desc)
        if ("$value $desc".contains("قبول العرض")) buttons.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, texts, buttons) }
    }

    private fun normalizeDigits(s: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val persian = "۰۱۲۳۴۵۶۷۸۹"
        return s.map { c ->
            when {
                c in arabic -> ('0'.code + arabic.indexOf(c)).toChar()
                c in persian -> ('0'.code + persian.indexOf(c)).toChar()
                else -> c
            }
        }.joinToString("")
    }

    private fun extractPrice(text: String): Double? {
        val t = normalizeDigits(text).replace(',', '.')
        val regex = Regex("(?i)(?:JOD\\s*)(\\d+(?:\\.\\d{1,3})?)|(\\d+(?:\\.\\d{1,3})?)\\s*JOD")
        val match = regex.find(t) ?: return null
        return (match.groups[1]?.value ?: match.groups[2]?.value)?.toDoubleOrNull()
    }

    private fun extractEta(text: String): Int? {
        val t = normalizeDigits(text)
        val regex = Regex("(\\d+)\\s*(?:دقيقة|دقائق|دقيقه|دقايق)")
        return regex.find(t)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        repeat(4) {
            if (parent != null && parent.isClickable) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            parent = parent?.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
