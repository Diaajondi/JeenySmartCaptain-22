package com.example.jeenysmartcaptain

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("captain", Context.MODE_PRIVATE) }
    private lateinit var minPrice: EditText
    private lateinit var maxMinutes: EditText
    private lateinit var enabled: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }
        layout.addView(TextView(this).apply { text = "Jeeny Smart Captain"; textSize = 25f })
        layout.addView(TextView(this).apply {
            text = "يقبل العرض فقط إذا تحقق شرط السعر وشرط وقت الوصول معاً."
            textSize = 16f
            setPadding(0, 16, 0, 20)
        })
        minPrice = EditText(this).apply {
            hint = "أقل سعر إجمالي بالدينار (مثال: 3.00)"
            inputType = 8194
            setText(prefs.getString("min_price", "3.00"))
        }
        layout.addView(minPrice)
        maxMinutes = EditText(this).apply {
            hint = "أقصى وقت وصول بالدقائق (مثال: 8)"
            inputType = 2
            setText(prefs.getInt("max_minutes", 8).toString())
        }
        layout.addView(maxMinutes)
        enabled = Switch(this).apply {
            text = "تفعيل القبول التلقائي"
            isChecked = prefs.getBoolean("enabled", false)
        }
        layout.addView(enabled)
        layout.addView(Button(this).apply {
            text = "حفظ الإعدادات"
            setOnClickListener {
                val p = minPrice.text.toString().trim().replace(',', '.').toDoubleOrNull()
                val m = maxMinutes.text.toString().trim().toIntOrNull()
                if (p == null || p < 0 || m == null || m < 0) {
                    Toast.makeText(this@MainActivity, "أدخل سعراً ووقتاً صحيحين", Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("min_price", p.toString())
                        .putInt("max_minutes", m).putBoolean("enabled", enabled.isChecked).apply()
                    Toast.makeText(this@MainActivity, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(TextView(this).apply {
            text = "يجب إبقاء جيني في الواجهة. القراءة تعتمد على إتاحة بيانات العرض في شجرة إمكانية الوصول؛ لا يوجد OCR في هذا النموذج."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
