package com.example.jeenysmartcaptain

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.media.Ringtone
import android.media.RingtoneManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("captain_multi", Context.MODE_PRIVATE) }
    private val bg = Color.rgb(13, 15, 31)
    private val panel = Color.rgb(27, 30, 54)
    private val panel2 = Color.rgb(35, 38, 67)
    private val purple = Color.rgb(139, 92, 246)
    private val white = Color.rgb(246, 245, 255)
    private val muted = Color.rgb(174, 177, 204)
    private var page = "home"
    private var selected = "jeeny"
    private var previewRingtone: Ringtone? = null
    private val ringtoneRequest = 4101
    private val audioFileRequest = 4102

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun params(w: Int = -1, h: Int = -2) = LinearLayout.LayoutParams(w, h)
    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render() }

    override fun onDestroy() { previewRingtone?.stop(); super.onDestroy() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            ringtoneRequest -> {
                val uri = data.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                prefs.edit().putString("notification_sound_uri", uri?.toString() ?: "system_default").apply()
                render()
            }
            audioFileRequest -> {
                val uri = data.data ?: return
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                prefs.edit().putString("notification_sound_uri", uri.toString()).apply()
                render()
            }
        }
    }

    private fun render() {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(18), dp(22), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(57, 37, 105), bg)).apply { cornerRadii = floatArrayOf(0f,0f,dp(26).toFloat(),dp(26).toFloat(),dp(26).toFloat(),dp(26).toFloat(),0f,0f) }
        }
        header.addView(label("JEENY SMART CAPTAIN", 19, white, true), params())
        header.addView(label(if (page == "home") "مركز التحكم" else "إعدادات المنصة", 22, white, true).apply { setPadding(0, dp(8), 0, dp(3)) }, params())
        header.addView(label(if (page == "home") "إدارة مستقلة لقبول عروض المنصات" else platformName(selected), 13, muted), params())
        root.addView(header, params())

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(20)) }
        if (page == "home") buildHome(body) else buildSettings(body)
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(12)); setBackgroundColor(panel) }
        nav.addView(navButton("الرئيسية", page == "home") { page = "home"; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navButton("إعدادات المنصة", page == "settings") { if (page == "home") { selected = "jeeny" }; page = "settings"; render() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(nav, params())
        setContentView(root)
    }

    private fun buildHome(body: LinearLayout) {
        body.addView(label("حالة المنصات", 18, white, true), params())
        body.addView(label("شغّل المنصة التي تستخدمها فقط", 12, muted).apply { setPadding(0, dp(4), 0, dp(14)) }, params())
        platformCard(body, "jeeny", "Jeeny", "السعر الأدنى • وقت الوصول")
        platformCard(body, "uber", "Uber Driver", "وقت الوصول • المسافة إلى العميل")
        platformCard(body, "taxif", "TaxiF Driver", "قيمة الرحلة • الوقت • المسافة")
        val service = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = rounded(panel, 18) }
        service.addView(label("خدمة إمكانية الوصول", 15, white, true), params())
        service.addView(label("يلزم تفعيل الخدمة يدوياً من إعدادات Android حتى يتمكن التطبيق من قراءة عروض المنصات.", 12, muted).apply { setPadding(0, dp(6), 0, dp(12)) }, params())
        val access = actionButton("فتح إعدادات إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        service.addView(access, params())
        body.addView(service, params().apply { topMargin = dp(8) })
        notificationSoundCard(body)
        body.addView(label("ملاحظة: نجاح إرسال أمر القبول لا يثبت قبول الرحلة. لا تعرض هذه النسخة أرباحاً مؤكدة قبل توفر إشارة موثوقة من المنصة.", 11, muted).apply { setPadding(dp(3), dp(14), dp(3), 0) }, params())
    }

    private fun platformCard(body: LinearLayout, key: String, title: String, summary: String) {
        val enabled = prefs.getBoolean("${key}_enabled", false)
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(panel, 18, if (enabled) purple else 0) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val nameCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        nameCol.addView(label(title, 17, white, true), params())
        nameCol.addView(label(summary, 11, muted).apply { setPadding(0, dp(3), 0, 0) }, params())
        top.addView(nameCol, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply { isChecked = enabled; buttonTintList = null; text = "" }
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("${key}_enabled", checked).apply(); render() }
        top.addView(sw, params(-2, -2))
        card.addView(top, params())
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        val state = label(if (enabled) "● مفعّل" else "○ متوقف", 12, if (enabled) Color.rgb(74, 222, 128) else muted, true)
        bottom.addView(state, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(actionButton("الإعدادات") { selected = key; page = "settings"; render() }, params(dp(112), dp(40)))
        card.addView(bottom, params())
        body.addView(card, params().apply { bottomMargin = dp(12) })
    }


    private fun notificationSoundCard(body: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(panel, 18)
        }
        card.addView(label("صوت إشعار قبول الطلب", 16, white, true), params())
        card.addView(label(soundLabel(), 12, muted).apply { setPadding(0, dp(5), 0, dp(12)) }, params())
        card.addView(actionButton("اختيار نغمة الهاتف") { openRingtonePicker() }, params().apply { bottomMargin = dp(8) })
        card.addView(actionButton("اختيار ملف صوتي من الهاتف") { openAudioPicker() }, params().apply { bottomMargin = dp(8) })
        card.addView(actionButton("تجربة النغمة") { previewSound() }, params())
        body.addView(card, params().apply { topMargin = dp(12) })
    }

    private fun soundLabel(): String {
        val uri = prefs.getString("notification_sound_uri", "system_default") ?: "system_default"
        return when {
            uri == "system_default" -> "النغمة الافتراضية للهاتف"
            uri.startsWith("content://media/") -> RingtoneManager.getRingtone(this, Uri.parse(uri))?.getTitle(this) ?: "نغمة محددة"
            else -> "ملف صوتي محدد"
        }
    }

    private fun openRingtonePicker() {
        val current = prefs.getString("notification_sound_uri", "system_default") ?: "system_default"
        val currentUri = if (current == "system_default") RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(current)
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختيار نغمة إشعار القبول")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, currentUri)
        }
        startActivityForResult(intent, ringtoneRequest)
    }

    private fun openAudioPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, audioFileRequest)
    }

    private fun previewSound() {
        try {
            previewRingtone?.stop()
            val stored = prefs.getString("notification_sound_uri", "system_default") ?: "system_default"
            val uri = if (stored == "system_default") RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(stored)
            previewRingtone = RingtoneManager.getRingtone(this, uri)
            previewRingtone?.play()
            if (previewRingtone == null) Toast.makeText(this, "تعذر تشغيل النغمة المحددة", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تعذر تشغيل النغمة المحددة", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildSettings(body: LinearLayout) {
        val selector = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = rounded(panel, 16); setPadding(dp(5), dp(5), dp(5), dp(5)) }
        listOf("jeeny" to "Jeeny", "uber" to "Uber", "taxif" to "TaxiF").forEach { (key, title) ->
            selector.addView(navButton(title, selected == key) { selected = key; render() }, LinearLayout.LayoutParams(0, dp(43), 1f))
        }
        body.addView(selector, params().apply { bottomMargin = dp(16) })
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(panel, 20); setPadding(dp(17), dp(17), dp(17), dp(17)) }
        card.addView(label(platformName(selected), 19, white, true), params())
        val enabled = Switch(this).apply { text = "تشغيل القبول التلقائي"; textSize = 14f; setTextColor(white); isChecked = prefs.getBoolean("${selected}_enabled", false) }
        enabled.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("${selected}_enabled", v).apply() }
        card.addView(enabled, params().apply { topMargin = dp(10); bottomMargin = dp(12) })
        when (selected) {
            "jeeny" -> { field(card, "jeeny_min_price", "أقل سعر إجمالي (دينار)", "3.00", true); field(card, "jeeny_max_eta", "أقصى وقت وصول (دقيقة)", "8", false) }
            "uber" -> { field(card, "uber_min_price", "أقل سعر للرحلة (دينار)", "3.00", true); field(card, "uber_max_eta", "أقصى وقت وصول (دقيقة)", "8", false); closeSwitch(card, "uber") }
            else -> { field(card, "taxif_min_price", "أقل قيمة للرحلة (دينار)", "3.00", true); field(card, "taxif_max_eta", "أقصى وقت وصول (دقيقة)", "8", false); field(card, "taxif_max_distance", "أقصى مسافة إلى العميل (كم)", "5", true); closeSwitch(card, "taxif") }
        }
        body.addView(card, params())
        body.addView(actionButton("العودة إلى الرئيسية") { page = "home"; render() }, params().apply { topMargin = dp(16) })
    }

    private fun field(card: LinearLayout, key: String, title: String, default: String, decimal: Boolean) {
        card.addView(label(title, 13, muted, true).apply { setPadding(0, dp(13), 0, dp(4)) }, params())
        val edit = EditText(this).apply {
            setSingleLine(true); textSize = 17f; setTextColor(white); setHintTextColor(muted); hint = default
            inputType = if (decimal) 8194 else 2
            setPadding(dp(13), dp(9), dp(13), dp(9)); background = rounded(panel2, 12)
            setText(prefs.getString(key, default))
        }
        // Save each valid edit immediately. This does not touch the platform-enabled
        // preference or the Android Accessibility Service state.
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                val value = s?.toString()?.trim().orEmpty()
                if (value.isNotEmpty()) prefs.edit().putString(key, value).apply()
            }
        })
        edit.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val value = edit.text.toString().trim()
                if (value.isNotEmpty()) prefs.edit().putString(key, value).apply()
            }
        }
        card.addView(edit, params().apply { topMargin = dp(3) })
    }

    private fun closeSwitch(card: LinearLayout, key: String) {
        val sw = Switch(this).apply { text = "إغلاق العرض غير المناسب بزر X"; textSize = 13f; setTextColor(white); isChecked = prefs.getBoolean("${key}_close", false) }
        sw.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("${key}_close", v).apply() }
        card.addView(sw, params().apply { topMargin = dp(15) })
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        textDirection = View.TEXT_DIRECTION_LOCALE
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 13f; isAllCaps = false; setTextColor(white); background = rounded(purple, 13)
        setOnClickListener { action() }
    }

    private fun navButton(text: String, active: Boolean, action: () -> Unit) = TextView(this).apply {
        this.text = text; gravity = Gravity.CENTER; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (active) white else muted); background = if (active) rounded(purple, 12) else rounded(Color.TRANSPARENT, 12)
        setOnClickListener { action() }
    }

    private fun platformName(key: String) = when (key) { "jeeny" -> "Jeeny"; "uber" -> "Uber Driver"; else -> "TaxiF Driver" }
}
