package com.example.jeenysmartcaptain

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Rect
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

class JeenyAccessibilityService : AccessibilityService() {
    private var lastActionAt = 0L
    private var lastOfferKey = ""

    private data class PriceCandidate(val value: Double, val bounds: Rect)
    private data class EtaCandidate(val minutes: Int, val bounds: Rect)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences("captain", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val root = rootInActiveWindow ?: return
        val prices = mutableListOf<PriceCandidate>()
        val etas = mutableListOf<EtaCandidate>()
        val acceptNodes = mutableListOf<AccessibilityNodeInfo>()
        collect(root, prices, etas, acceptNodes)

        val accept = acceptNodes.firstOrNull() ?: return
        val acceptBounds = Rect().also { accept.getBoundsInScreen(it) }
        if (acceptBounds.isEmpty) return

        // ETA is taken from the offer card. The fare must be below the ETA
        // and above the Accept button, excluding the separate top JOD balance.
        val eta = etas
            .filter { it.bounds.centerY() < acceptBounds.centerY() }
            .minByOrNull { abs(acceptBounds.centerY() - it.bounds.centerY()) }
            ?: return

        val fare = prices
            .filter {
                it.bounds.centerY() > eta.bounds.centerY() &&
                    it.bounds.centerY() < acceptBounds.centerY()
            }
            .minByOrNull { abs(it.bounds.centerY() - eta.bounds.centerY()) }
            ?: return

        val minPrice = prefs.getString("min_price", "3.00")?.toDoubleOrNull() ?: return
        val maxMinutes = prefs.getInt("max_minutes", 8)
        val offerKey = "${fare.value}|${eta.minutes}|${fare.bounds.flattenToString()}"
        if (offerKey == lastOfferKey) return

        if (fare.value < minPrice || eta.minutes > maxMinutes) {
            lastOfferKey = offerKey
            Log.i(TAG, "Ignored offer: price=${fare.value}, eta=${eta.minutes}")
            return
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastActionAt < ACTION_COOLDOWN_MS) return

        // Only click the labelled Accept control or its clickable parent.
        val clicked = clickNodeOrParent(accept)
        if (clicked) {
            lastOfferKey = offerKey
            lastActionAt = now
        }
        Log.i(TAG, "Accept action=$clicked, price=${fare.value}, eta=${eta.minutes}")
    }

    private fun collect(
        node: AccessibilityNodeInfo,
        prices: MutableList<PriceCandidate>,
        etas: MutableList<EtaCandidate>,
        acceptNodes: MutableList<AccessibilityNodeInfo>
    ) {
        val value = node.text?.toString()?.trim().orEmpty()
        val description = node.contentDescription?.toString()?.trim().orEmpty()
        val ownText = listOf(value, description).filter { it.isNotBlank() }.joinToString(" ")
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        if (ownText.contains("قبول العرض")) acceptNodes.add(node)

        if (!bounds.isEmpty && ownText.isNotBlank()) {
            extractPrice(ownText)?.let { prices.add(PriceCandidate(it, Rect(bounds))) }
            extractEta(ownText)?.let { etas.add(EtaCandidate(it, Rect(bounds))) }
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collect(child, prices, etas, acceptNodes)
            }
        }
    }

    private fun normalizeDigits(text: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val persian = "۰۱۲۳۴۵۶۷۸۹"
        return text.map { c ->
            when {
                c in arabic -> ('0'.code + arabic.indexOf(c)).toChar()
                c in persian -> ('0'.code + persian.indexOf(c)).toChar()
                else -> c
            }
        }.joinToString("")
    }

    private fun extractPrice(text: String): Double? {
        val normalized = normalizeDigits(text).replace(',', '.')
        val regex = Regex(
            """(?i)\bJOD\s*(\d+(?:\.\d{1,3})?)|(?:دينار|دنانير|د\.أ)\s*(\d+(?:\.\d{1,3})?)|(\d+(?:\.\d{1,3})?)\s*(?:JOD|دينار|دنانير|د\.أ)"""
        )
        val match = regex.find(normalized) ?: return null
        return (1..3).firstNotNullOfOrNull { match.groups[it]?.value?.toDoubleOrNull() }
    }

    private fun extractEta(text: String): Int? {
        val normalized = normalizeDigits(text)
        val regex = Regex(
            """(?:يبعد\s*)?(\d+)\s*(?:دقيقة|دقائق|دقيقه|دقايق|minutes?|mins?)""",
            RegexOption.IGNORE_CASE
        )
        return regex.find(normalized)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        repeat(4) {
            if (parent != null && parent.isClickable) {
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            parent = parent?.parent
        }
        return false
    }

    override fun onInterrupt() {}

    companion object {
        private const val TAG = "JeenyCaptain"
        private const val ACTION_COOLDOWN_MS = 1800L
    }
}
