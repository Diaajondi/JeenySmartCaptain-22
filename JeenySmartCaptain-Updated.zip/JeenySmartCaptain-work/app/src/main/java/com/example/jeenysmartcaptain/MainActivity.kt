package com.example.jeenysmartcaptain

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("captain", Context.MODE_PRIVATE) }
    private lateinit var minPrice: EditText
    private lateinit var maxMinutes: EditText
    private lateinit var enabled: Switch
    private lateinit var soundEnabled: Switch
    private lateinit var acceptedValue: TextView
    private lateinit var rejectedValue: TextView
    private lateinit var statusValue: TextView
    private lateinit var lastActionValue: TextView

    private val purple = Color.rgb(112, 48, 168)
    private val deepPurple = Color.rgb(76, 29, 118)
    private val ink = Color.rgb(35, 31, 45)
    private val muted = Color.rgb(125, 119, 137)
    private val canvas = Color.rgb(247, 245, 250)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = deepPurple
        window.navigationBarColor = canvas
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::acceptedValue.isInitialized) refreshStats()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(canvas); clipToPadding = false }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(page)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(deepPurple, 24)
            setPadding(dp(20), dp(22), dp(20), dp(22))
        }
        val logoView = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(76), dp(76)).apply { bottomMargin = dp(12) }
            contentDescription = "Jeeny Smart Captain"
        }
        header.addView(logoView)
        header.addView(label("Jeeny Smart Captain", 24, Color.WHITE, true))
        header.addView(label("مساعد قبول الطلبات الذكي", 15, Color.rgb(232, 220, 246), false).apply { setPadding(0, dp(5), 0, 0) })
        val headerStatus = TextView(this).apply {
            text = if (prefs.getBoolean("enabled", false)) "● القبول التلقائي مفعّل" else "● القبول التلقائي متوقف"
            textSize = 13f; setTextColor(Color.WHITE); setPadding(0, dp(16), 0, 0)
        }
        header.addView(headerStatus)
        page.addView(header, matchWrap())

        page.addView(sectionTitle("لوحة التحكم"))
        val controlCard = card()
        controlCard.addView(label("شروط قبول الرحلة", 17, ink, true))
        controlCard.addView(label("لن يقبل التطبيق إلا إذا تحقق السعر والوقت معاً.", 13, muted, false).apply { setPadding(0, dp(4), 0, dp(12)) })

        val fields = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val priceBox = fieldColumn("الحد الأدنى للسعر (JOD)")
        minPrice = EditText(this).apply {
            setSingleLine(true); textSize = 20f; setTextColor(ink); setHintTextColor(muted)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            gravity = Gravity.CENTER; setText(prefs.getString("min_price", "3.00"))
            background = rounded(canvas, 14); setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        priceBox.addView(minPrice, matchWrap())
        val etaBox = fieldColumn("أقصى وقت وصول")
        maxMinutes = EditText(this).apply {
            setSingleLine(true); textSize = 20f; setTextColor(ink); setHintTextColor(muted)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            gravity = Gravity.CENTER; setText(prefs.getInt("max_minutes", 8).toString())
            background = rounded(canvas, 14); setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        etaBox.addView(maxMinutes, matchWrap())
        fields.addView(priceBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        fields.addView(etaBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
        controlCard.addView(fields)

        enabled = Switch(this).apply {
            text = "تفعيل القبول التلقائي"; textSize = 16f; setTextColor(ink)
            isChecked = prefs.getBoolean("enabled", false)
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
                headerStatus.text = if (checked) "● القبول التلقائي مفعّل" else "● القبول التلقائي متوقف"
                refreshStats()
            }
        }
        controlCard.addView(enabled)

        soundEnabled = Switch(this).apply {
            text = "تنبيه صوتي بعد تنفيذ الإجراء"
            textSize = 15f
            setTextColor(ink)
            isChecked = prefs.getBoolean("sound_enabled", true)
            setPadding(0, dp(8), 0, dp(4))
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("sound_enabled", checked).apply()
            }
        }
        controlCard.addView(soundEnabled)

        val save = actionButton("حفظ الشروط", purple)
        save.setOnClickListener { saveSettings() }
        controlCard.addView(save, matchWrap().apply { topMargin = dp(10) })
        page.addView(controlCard, matchWrap())

        page.addView(sectionTitle("إحصائيات الإجراءات"))
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val acceptedCard = statCard("ضغطات القبول", "0", Color.rgb(32, 145, 104))
        acceptedValue = acceptedCard.second
        val rejectedCard = statCard("ضغطات الرفض", "0", Color.rgb(202, 91, 75))
        rejectedValue = rejectedCard.second
        stats.addView(acceptedCard.first, LinearLayout.LayoutParams(0, dp(108), 1f).apply { marginEnd = dp(6) })
        stats.addView(rejectedCard.first, LinearLayout.LayoutParams(0, dp(108), 1f).apply { marginStart = dp(6) })
        page.addView(stats)

        page.addView(sectionTitle("حالة المساعد"))
        val statusCard = card()
        statusValue = label("بانتظار تفعيل خدمة إمكانية الوصول", 15, ink, true)
        lastActionValue = label("آخر نشاط: لا يوجد بعد", 13, muted, false).apply { setPadding(0, dp(8), 0, 0) }
        statusCard.addView(statusValue); statusCard.addView(lastActionValue)
        val access = actionButton("فتح إعدادات إمكانية الوصول", deepPurple)
        access.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        statusCard.addView(access, matchWrap().apply { topMargin = dp(14) })
        page.addView(statusCard, matchWrap())

        page.addView(sectionTitle("آخر نتيجة"))
        val logCard = card()
        logCard.addView(label("يعرض التطبيق آخر قرار سجّلته خدمة القراءة.", 13, muted, false))
        page.addView(logCard, matchWrap())

        page.addView(label("ملاحظة: يجب إبقاء Jeeny في الواجهة. تعتمد القراءة على عناصر إمكانية الوصول التي يعرضها إصدار Jeeny لديك؛ لا يتضمن هذا الإصدار OCR. اختبر القراءة أولاً والقبول التلقائي متوقفاً.", 12, muted, false).apply { setPadding(dp(4), dp(16), dp(4), 0) })
        setContentView(scroll)
        refreshStats()
    }

    private fun saveSettings() {
        val price = minPrice.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val minutes = maxMinutes.text.toString().trim().toIntOrNull()
        if (price == null || price < 0 || minutes == null || minutes < 0) {
            Toast.makeText(this, "أدخل سعراً ووقتاً صحيحين", Toast.LENGTH_LONG).show(); return
        }
        prefs.edit().putString("min_price", price.toString()).putInt("max_minutes", minutes)
            .putBoolean("enabled", enabled.isChecked)
            .putBoolean("sound_enabled", soundEnabled.isChecked).apply()
        Toast.makeText(this, "تم حفظ الشروط", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStats() {
        if (!::acceptedValue.isInitialized) return
        acceptedValue.text = prefs.getInt("accepted_count", 0).toString()
        rejectedValue.text = prefs.getInt("rejected_count", 0).toString()
        val active = prefs.getBoolean("enabled", false)
        statusValue.text = if (active) "القبول التلقائي قيد التشغيل" else "القبول التلقائي متوقف"
        lastActionValue.text = prefs.getString("last_action", "آخر نشاط: لا يوجد بعد")
    }

    private fun sectionTitle(text: String) = label(text, 18, ink, true).apply { setPadding(dp(2), dp(22), dp(2), dp(10)) }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(Color.WHITE, 20); elevation = dp(2).toFloat()
    }
    private fun fieldColumn(title: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(label(title, 12, muted, true).apply { setPadding(0, 0, 0, dp(7)) })
    }
    private fun statCard(title: String, value: String, color: Int): Pair<LinearLayout, TextView> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = rounded(Color.WHITE, 18); elevation = dp(2).toFloat() }
        box.addView(label(title, 12, muted, false))
        val number = label(value, 27, color, true)
        box.addView(number)
        return box to number
    }
    private fun actionButton(text: String, color: Int) = TextView(this).apply {
        this.text = text; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(Color.WHITE); background = rounded(color, 14); setPadding(dp(12), dp(14), dp(12), dp(14)); isClickable = true; isFocusable = true
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); gravity = Gravity.RIGHT
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
