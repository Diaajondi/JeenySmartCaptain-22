package com.example.jeenysmartcaptain

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.graphics.Rect
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs

class JeenyAccessibilityService : AccessibilityService() {
    private var lastOfferKey = ""

    private data class PriceCandidate(val value: Double, val bounds: Rect)
    private data class EtaCandidate(val minutes: Int, val bounds: Rect)
    private data class ClickCandidate(
        val node: AccessibilityNodeInfo,
        val bounds: Rect,
        val label: String,
        val clickable: Boolean
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val prefs = getSharedPreferences("captain", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", false)) return

        val root = rootInActiveWindow ?: return
        val prices = mutableListOf<PriceCandidate>()
        val etas = mutableListOf<EtaCandidate>()
        val acceptNodes = mutableListOf<AccessibilityNodeInfo>()
        val clickCandidates = mutableListOf<ClickCandidate>()
        collect(root, prices, etas, acceptNodes, clickCandidates)

        val accept = acceptNodes.firstOrNull()
        if (accept == null) {
            // The offer card is no longer visible; allow an identical future offer.
            lastOfferKey = ""
            return
        }
        val acceptBounds = Rect().also { accept.getBoundsInScreen(it) }
        if (acceptBounds.isEmpty) return

        // ETA is taken from the offer card. The fare must be below the ETA
        // and above the Accept button, excluding the separate top JOD balance.
        val eta = etas
            .filter { it.bounds.centerY() < acceptBounds.centerY() }
            .minByOrNull { abs(acceptBounds.centerY() - it.bounds.centerY()) }
            ?: return

        val fare = prices
            .filter {
                it.bounds.centerY() > eta.bounds.centerY() &&
                    it.bounds.centerY() < acceptBounds.centerY()
            }
            .minByOrNull { abs(it.bounds.centerY() - eta.bounds.centerY()) }
            ?: return

        val minPrice = prefs.getString("min_price", "3.00")?.toDoubleOrNull() ?: return
        val maxMinutes = prefs.getInt("max_minutes", 8)
        val offerKey = "${fare.value}|${eta.minutes}|${fare.bounds.flattenToString()}"
        if (offerKey == lastOfferKey) return

        if (fare.value < minPrice || eta.minutes > maxMinutes) {
            // Dismiss only a small, clickable X/close control belonging to this offer card.
            // There is deliberately no coordinate-tap fallback.
            val dismissed = clickRejectControl(clickCandidates, eta.bounds, acceptBounds)
            if (dismissed) {
                lastOfferKey = offerKey
                recordDecision(accepted = false, price = fare.value, eta = eta.minutes, detail = "تم رفض عرض غير مطابق")
                playDecisionTone(accepted = false)
            }
            Log.i(TAG, "Rejected offer: dismissed=$dismissed, price=${fare.value}, eta=${eta.minutes}")
            return
        }

        // Only click the labelled Accept control or its clickable parent.
        val clicked = clickNodeOrParent(accept)
        if (clicked) {
            lastOfferKey = offerKey
            recordDecision(accepted = true, price = fare.value, eta = eta.minutes, detail = "تم تنفيذ ضغط القبول")
            playDecisionTone(accepted = true)
        }
        Log.i(TAG, "Accept action=$clicked, price=${fare.value}, eta=${eta.minutes}")
    }


    private fun recordDecision(accepted: Boolean, price: Double, eta: Int, detail: String) {
        val prefs = getSharedPreferences("captain", Context.MODE_PRIVATE)
        val countKey = if (accepted) "accepted_count" else "rejected_count"
        val count = prefs.getInt(countKey, 0) + 1
        val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        prefs.edit()
            .putInt(countKey, count)
            .putString("last_action", "$detail • ${String.format(java.util.Locale.US, "%.2f", price)} JOD • $eta د • $time")
            .apply()
    }

    private fun playDecisionTone(accepted: Boolean) {
        val prefs = getSharedPreferences("captain", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("sound_enabled", true)) return
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
            tone.startTone(
                if (accepted) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK,
                if (accepted) 180 else 120
            )
            android.os.Handler(mainLooper).postDelayed({ tone.release() }, 350)
        } catch (e: Exception) {
            Log.w(TAG, "Could not play decision tone", e)
        }
    }

    private fun collect(
        node: AccessibilityNodeInfo,
        prices: MutableList<PriceCandidate>,
        etas: MutableList<EtaCandidate>,
        acceptNodes: MutableList<AccessibilityNodeInfo>,
        clickCandidates: MutableList<ClickCandidate>
    ) {
        val value = node.text?.toString()?.trim().orEmpty()
        val description = node.contentDescription?.toString()?.trim().orEmpty()
        val ownText = listOf(value, description).filter { it.isNotBlank() }.joinToString(" ")
        val bounds = Rect()
        node.getBoundsInScreen(bounds)

        if (ownText.contains("قبول العرض")) acceptNodes.add(node)
        if (!bounds.isEmpty && (node.isClickable || ownText.isNotBlank())) {
            clickCandidates.add(ClickCandidate(node, Rect(bounds), ownText.lowercase(), node.isClickable))
        }

        if (!bounds.isEmpty && ownText.isNotBlank()) {
            extractPrice(ownText)?.let { prices.add(PriceCandidate(it, Rect(bounds))) }
            extractEta(ownText)?.let { etas.add(EtaCandidate(it, Rect(bounds))) }
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                collect(child, prices, etas, acceptNodes, clickCandidates)
            }
        }
    }


    private fun clickRejectControl(
        candidates: List<ClickCandidate>,
        etaBounds: Rect,
        acceptBounds: Rect
    ): Boolean {
        val density = resources.displayMetrics.density
        val maxWidth = (88f * density).toInt()
        val maxHeight = (88f * density).toInt()
        val minY = etaBounds.top - (190f * density).toInt()
        val maxY = etaBounds.top + (24f * density).toInt()

        // Prefer an explicit accessibility label when Jeeny exposes one.
        val labelled = candidates
            .filter {
                it.clickable && it.bounds.width() in 1..maxWidth &&
                    it.bounds.height() in 1..maxHeight &&
                    it.bounds.centerY() in minY..maxY &&
                    it.bounds.centerY() < acceptBounds.centerY() &&
                    (it.label.contains("رفض") || it.label.contains("إغلاق") ||
                     it.label.contains("اغلاق") || it.label.contains("close") ||
                     it.label == "x" || it.label.contains("dismiss"))
            }
            .minByOrNull { it.bounds.centerY() }
        if (labelled != null) return labelled.node.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        // Screenshot reference: the X is a small circular control on the left
        // of the offer header, just above the ETA. Geometry is tightly bounded.
        val screenWidth = resources.displayMetrics.widthPixels
        val geometric = candidates
            .filter {
                it.clickable && it.bounds.width() in 1..maxWidth &&
                    it.bounds.height() in 1..maxHeight &&
                    it.bounds.centerX() < screenWidth / 3 &&
                    it.bounds.centerY() in minY..maxY &&
                    it.bounds.centerY() < acceptBounds.centerY()
            }
            .minByOrNull { kotlin.math.abs((etaBounds.top - it.bounds.centerY()).toDouble()) }
        return geometric?.node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun normalizeDigits(text: String): String {
        val arabic = "٠١٢٣٤٥٦٧٨٩"
        val persian = "۰۱۲۳۴۵۶۷۸۹"
        return text.map { c ->
            when {
                c in arabic -> ('0'.code + arabic.indexOf(c)).toChar()
                c in persian -> ('0'.code + persian.indexOf(c)).toChar()
                else -> c
            }
        }.joinToString("")
    }

    private fun extractPrice(text: String): Double? {
        val normalized = normalizeDigits(text).replace(',', '.')
        val regex = Regex(
            """(?i)\bJOD\s*(\d+(?:\.\d{1,3})?)|(?:دينار|دنانير|د\.أ)\s*(\d+(?:\.\d{1,3})?)|(\d+(?:\.\d{1,3})?)\s*(?:JOD|دينار|دنانير|د\.أ)"""
        )
        val match = regex.find(normalized) ?: return null
        return (1..3).firstNotNullOfOrNull { match.groups[it]?.value?.toDoubleOrNull() }
    }

    private fun extractEta(text: String): Int? {
        val normalized = normalizeDigits(text)
        val regex = Regex(
            """(?:يبعد\s*)?(\d+)\s*(?:دقيقة|دقائق|دقيقه|دقايق|minutes?|mins?)""",
            RegexOption.IGNORE_CASE
        )
        return regex.find(normalized)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var parent = node.parent
        repeat(4) {
            if (parent != null && parent.isClickable) {
                return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            parent = parent?.parent
        }
        return false
    }

    override fun onInterrupt() {}

    companion object {
        private const val TAG = "JeenyCaptain"
    }
}
