# Keep Android accessibility service entry points and reflection-safe app components.
-keep class com.example.jeenysmartcaptain.JeenyAccessibilityService { *; }
-keep class com.example.jeenysmartcaptain.MainActivity { *; }
