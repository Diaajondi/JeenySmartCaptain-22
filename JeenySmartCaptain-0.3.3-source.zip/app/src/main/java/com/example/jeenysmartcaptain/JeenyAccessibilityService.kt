package com.example.jeenysmartcaptain

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.net.Uri
import android.media.RingtoneManager
import android.graphics.Path
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class JeenyAccessibilityService : AccessibilityService() {
    private var lastActionAt=0L
    private var lastOfferKey=""
    private var pendingAcceptAt=0L
    private var tts:TextToSpeech?=null
    override fun onServiceConnected(){ super.onServiceConnected(); tts=TextToSpeech(this){ if(it==TextToSpeech.SUCCESS) tts?.language=Locale("ar") } }
    override fun onDestroy(){ tts?.shutdown(); super.onDestroy() }

    override fun onAccessibilityEvent(event:AccessibilityEvent?) {
        if(event==null || event.packageName==null) return
        if(event.eventType !in setOf(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,AccessibilityEvent.TYPE_VIEW_SCROLLED,AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED)) return
        val platform=detectPlatform(event.packageName.toString()) ?: return
        val prefs=getSharedPreferences("captain_multi",Context.MODE_PRIVATE)
        if(!prefs.getBoolean("${platform}_enabled",false)) return
        val now=SystemClock.elapsedRealtime(); if(now-lastActionAt<450) return
        val root=rootInActiveWindow ?: return
        val text=treeText(root)
        if(text.isBlank()) return
        if(pendingAcceptAt > 0L) {
            if(now - pendingAcceptAt > 10000L) {
                pendingAcceptAt = 0L
            } else if(isAcceptanceConfirmed(text)) {
                playAcceptanceSound(prefs)
                pendingAcceptAt = 0L
                Log.i("SmartCaptain", "$platform acceptance confirmation detected; notification sound played")
            }
        }
        val offer=parseOffer(platform,text) ?: return
        val key="$platform|${offer.price}|${offer.eta}|${offer.distance}|${text.hashCode()}"
        if(key==lastOfferKey || now-lastActionAt<900) return
        val acceptable=when(platform){
            "jeeny" -> offer.price!=null && offer.eta!=null && offer.price>=numberPref(prefs,"jeeny_min_price",3.0) && offer.eta<=intPref(prefs,"jeeny_max_eta",8)
            "uber" -> offer.eta!=null && offer.distance!=null && offer.eta<=intPref(prefs,"uber_max_eta",8) && offer.distance<=numberPref(prefs,"uber_max_distance",5.0)
            else -> offer.price!=null && offer.eta!=null && offer.distance!=null && offer.price>=numberPref(prefs,"taxif_min_price",3.0) && offer.eta<=intPref(prefs,"taxif_max_eta",8) && offer.distance<=numberPref(prefs,"taxif_max_distance",5.0)
        }
        if(!acceptable){
            lastOfferKey=key; lastActionAt=now
            if(platform!="jeeny" && prefs.getBoolean("${platform}_close",false)) findClose(root)?.let{click(it)}
            Log.i("SmartCaptain","$platform offer rejected by configured rules; missing values fail closed")
            return
        }
        val accept=findAccept(root,platform) ?: return
        lastOfferKey=key; lastActionAt=now
        val dispatched=if(platform=="taxif") swipeAccept(accept) else click(accept)
        if(dispatched) pendingAcceptAt=now
        Log.i("SmartCaptain","$platform accept action dispatched=$dispatched; awaiting app confirmation")
    }

    private fun isAcceptanceConfirmed(raw:String):Boolean {
        val t=norm(raw).lowercase()
        val confirmations=listOf(
            "تم قبول الرحلة", "تم قبول الطلب", "تم قبول العرض", "تم تأكيد الرحلة", "تم استلام الرحلة",
            "رحلة مقبولة", "تمت الموافقة على الرحلة",
            "trip accepted", "ride accepted", "accepted successfully",
            "request accepted", "booking confirmed"
        )
        return confirmations.any { t.contains(it) }
    }

    private fun playAcceptanceSound(prefs:android.content.SharedPreferences) {
        try {
            val stored=prefs.getString("notification_sound_uri","system_default") ?: "system_default"
            val uri=if(stored=="system_default") RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(stored)
            val tone=RingtoneManager.getRingtone(this,uri) ?: return
            tone.play()
        } catch(e:Exception) {
            Log.w("SmartCaptain","Unable to play selected notification sound",e)
        }
    }

    private data class Offer(val price:Double?,val eta:Int?,val distance:Double?)
    private fun detectPlatform(pkg:String):String? {
        val s=pkg.lowercase()
        val label=try{packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString().lowercase()}catch(_:Exception){""}
        val v="$s $label"
        return when { "jeeny" in v -> "jeeny"; "uber" in v -> "uber"; "taxif" in v || "taxi-f" in v || "taxi f" in v -> "taxif"; else -> null }
    }
    private fun treeText(n:AccessibilityNodeInfo):String { val a=mutableListOf<String>(); fun walk(x:AccessibilityNodeInfo){ x.text?.toString()?.trim()?.takeIf{it.isNotEmpty()}?.let(a::add); x.contentDescription?.toString()?.trim()?.takeIf{it.isNotEmpty()}?.let(a::add); for(i in 0 until x.childCount) x.getChild(i)?.let(::walk) }; walk(n); return a.distinct().joinToString(" | ") }
    private fun norm(s:String)=s.map{ when(it){ in '٠'..'٩' -> ('0'.code+it.code-'٠'.code).toChar(); in '۰'..'۹' -> ('0'.code+it.code-'۰'.code).toChar(); '٫'->'.'; '٬'->','; else->it } }.joinToString("").replace(',', '.')
    private fun parseOffer(platform:String,raw:String):Offer? {
        val t=norm(raw).lowercase()
        val eta=Regex("(\\d{1,3})\\s*(?:دقيقة|دقائق|دقيقه|دقايق|min(?:s|ute|utes)?)").find(t)?.groupValues?.get(1)?.toIntOrNull()
        val distRegex=Regex("(\\d{1,3}(?:\\.\\d{1,2})?)\\s*(?:كم|كيلومتر|km|kilometers?)")
        val distance=distRegex.find(t)?.groupValues?.get(1)?.toDoubleOrNull()
        val currency=Regex("(?i)(?:jod|jd|د\\.?أ|دينار(?: أردني)?)\\s*(\\d{1,5}(?:\\.\\d{1,2})?)|(\\d{1,5}(?:\\.\\d{1,2})?)\\s*(?:jod|jd|د\\.?أ|دينار(?: أردني)?)")
        val money=currency.findAll(t).mapNotNull{(it.groups[1]?.value?:it.groups[2]?.value)?.toDoubleOrNull()}.distinct().toList()
        val totalWords=listOf("السعر الإجمالي","السعر الاجمالي","الإجمالي","الاجمالي","قيمة الرحلة","قيمة الطلب","total fare","total")
        var price:Double?=null
        for(label in totalWords){ val ix=t.indexOf(label); if(ix>=0){ val tail=t.substring(ix).take(100); price=currency.find(tail)?.let{(it.groups[1]?.value?:it.groups[2]?.value)?.toDoubleOrNull()}; if(price!=null) break } }
        if(price==null && money.size==1) price=money.single()
        if(platform=="uber") price=null
        return if(eta==null && distance==null && price==null) null else Offer(price,eta,distance)
    }
    private fun numberPref(p:android.content.SharedPreferences,k:String,d:Double)=norm(p.getString(k,d.toString())?:d.toString()).toDoubleOrNull()?:d
    private fun intPref(p:android.content.SharedPreferences,k:String,d:Int)=norm(p.getString(k,d.toString())?:d.toString()).toDoubleOrNull()?.toInt()?:d
    private fun findAccept(root:AccessibilityNodeInfo,platform:String):AccessibilityNodeInfo? {
        val words=if(platform=="jeeny") listOf("قبول العرض","قبول الطلب","accept") else listOf("قبول","accept","اسحب للقبول","slide to accept")
        return findNode(root){n-> val s="${n.text?:""} ${n.contentDescription?:""}".lowercase(); words.any{s.contains(it)} && (n.isClickable || hasClickableParent(n) || platform=="taxif") }
    }
    private fun findClose(root:AccessibilityNodeInfo)=findNode(root){n-> val s="${n.text?:""} ${n.contentDescription?:""}".trim().lowercase(); (s=="x"||s=="×"||s.contains("إغلاق")||s.contains("close"))&&(n.isClickable||hasClickableParent(n)) }
    private fun findNode(root:AccessibilityNodeInfo,match:(AccessibilityNodeInfo)->Boolean):AccessibilityNodeInfo? { if(match(root)) return root; for(i in 0 until root.childCount){ val c=root.getChild(i)?:continue; val r=findNode(c,match); if(r!=null)return r }; return null }
    private fun hasClickableParent(n:AccessibilityNodeInfo):Boolean { var p=n.parent; repeat(4){if(p?.isClickable==true)return true;p=p?.parent};return false }
    private fun click(n:AccessibilityNodeInfo):Boolean { if(n.isClickable)return n.performAction(AccessibilityNodeInfo.ACTION_CLICK); var p=n.parent; repeat(4){if(p?.isClickable==true)return p.performAction(AccessibilityNodeInfo.ACTION_CLICK);p=p?.parent};return false }
    private fun swipeAccept(n:AccessibilityNodeInfo):Boolean {
        val r=android.graphics.Rect(); n.getBoundsInScreen(r); if(r.width()<40||r.height()<20)return click(n)
        val path=Path().apply{moveTo(r.left+r.width()*0.12f,r.centerY().toFloat());lineTo(r.right-r.width()*0.08f,r.centerY().toFloat())}
        val stroke=GestureDescription.StrokeDescription(path,0,420)
        return dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(),null,null)
    }
    override fun onInterrupt(){}
}
